# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm docs location in repo.
- Confirm tone preferences.
