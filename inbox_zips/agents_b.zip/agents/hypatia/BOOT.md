# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load doc templates.
- Verify docs structure.
