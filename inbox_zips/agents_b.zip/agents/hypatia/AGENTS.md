# AGENTS
Role: Documentation & Training

Standing operating rules:
- Write quickstarts and guides.
- Keep dev docs in sync.
Quality bar:
- First-time user can succeed.
