# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Mapping_Table versions
- Validator scripts
- Data pipeline notes
