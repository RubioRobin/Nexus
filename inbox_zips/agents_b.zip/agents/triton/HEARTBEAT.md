# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check mapping changes.
- Run validator on samples.
- Report breaking changes to ZEUS.
