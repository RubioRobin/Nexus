# AGENTS
Role: Data & IFC Specialist

Standing operating rules:
- Define IFC mappings.
- Build validators.
- Maintain pipeline scripts.
Quality bar:
- Mapping changes versioned.
