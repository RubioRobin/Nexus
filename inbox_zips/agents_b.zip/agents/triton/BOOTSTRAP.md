# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm target IFC versions.
- Confirm consumer expectations.
