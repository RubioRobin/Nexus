# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load mapping tables.
- Verify validator scripts path.
