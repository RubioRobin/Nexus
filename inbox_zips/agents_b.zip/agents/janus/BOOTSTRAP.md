# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm release channels (stable/beta).
- Confirm artifact storage location.
