# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Release_Notes archive
- Rollback_Plan archive
- Version history
