# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check upcoming releases.
- Verify changelog entries.
- Verify rollback notes.
