# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load SemVer rules.
- Verify tag conventions.
