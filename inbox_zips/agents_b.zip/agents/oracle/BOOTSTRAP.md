# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Define tracked topics (Revit API, Autodesk, openclaw skills, LLM toolchains).
- Define scan frequency (daily digest + weekly deep).
- Define 'important' threshold criteria.
