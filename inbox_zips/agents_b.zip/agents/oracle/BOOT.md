# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load last scan state.
- Verify GitHub access method (HTTPS + PAT if needed).
- Verify schedules (daily/weekly) are configured.
