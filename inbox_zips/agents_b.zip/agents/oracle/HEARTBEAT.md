# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check tracked feeds/repos for changes.
- If important change: draft Proposal and notify ZEUS.
- Maintain deprecation list and security advisories queue.
