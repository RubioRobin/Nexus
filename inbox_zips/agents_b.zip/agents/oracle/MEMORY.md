# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Tracked repositories list
- Weekly_AI_Report.md
- Skill_Upgrade_Proposal.md
- Deprecation_Alerts.md
