# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check new rules added in projects.
- Ensure traceability updated.
- Flag ambiguous interpretations.
