# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Compliance_Rulebook
- Traceability_Matrix
- Report templates
