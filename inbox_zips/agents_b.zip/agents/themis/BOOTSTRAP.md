# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm applicable compliance domains.
- Confirm evidence storage approach.
