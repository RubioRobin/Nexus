# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load traceability templates.
- Verify report folder exists.
