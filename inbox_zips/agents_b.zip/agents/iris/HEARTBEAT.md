# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check pending test runs.
- Verify regression checklist updated.
- Alert ZEUS if release criteria not met.
