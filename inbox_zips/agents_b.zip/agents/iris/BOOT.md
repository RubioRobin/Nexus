# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load test templates.
- Verify artifact directory.
