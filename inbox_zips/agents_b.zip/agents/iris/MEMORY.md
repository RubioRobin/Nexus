# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Test_Report archive
- Regression_Checklist versions
- Release sign-off history
