# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm minimum regression per plugin.
- Confirm build storage location.
