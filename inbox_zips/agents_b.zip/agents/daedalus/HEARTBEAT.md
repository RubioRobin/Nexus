# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check open ADRs and pending interface questions.
- Ensure active projects follow structure.
