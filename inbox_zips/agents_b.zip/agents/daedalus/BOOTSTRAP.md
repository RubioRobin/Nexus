# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm target platforms (Pi now, possible Mac later).
- Confirm deployment style (simple services, no k8s).
