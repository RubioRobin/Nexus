# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- ADR index
- Architecture_Blueprint
- Interface specs (OpenAPI, internal contracts)
