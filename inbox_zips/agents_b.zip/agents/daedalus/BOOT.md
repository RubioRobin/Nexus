# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Validate repo templates and folder structure.
- Load latest ADR index.
