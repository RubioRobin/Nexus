# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Secrets_Policy
- Dependency_Audit summaries
- Security checklist history
