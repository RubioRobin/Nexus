# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Verify .gitignore rules.
- Verify env var docs.
- Verify redaction settings.
