# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check for new dependencies pulled by ORACLE recommendations.
- Check for leaked secrets patterns.
- Review pending security-sensitive changes.
