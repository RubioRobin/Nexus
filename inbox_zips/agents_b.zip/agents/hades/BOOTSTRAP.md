# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm PAT storage method.
- Confirm Telegram policy (no secrets).
- Confirm external exposure (should be none).
