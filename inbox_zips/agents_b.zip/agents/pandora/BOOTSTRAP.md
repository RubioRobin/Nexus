# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm default product focus (Revit tool factory).
- Confirm allowed side-scope (planning website requests).
- Define release cadence (weekly/biweekly).
