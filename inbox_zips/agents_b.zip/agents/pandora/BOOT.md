# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load current PRD + backlog.
- Verify acceptance checklist templates present.
- Sync PRD changes to GitHub.
