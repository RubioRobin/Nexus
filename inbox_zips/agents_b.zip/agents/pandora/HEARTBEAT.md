# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check for scope drift in active tasks.
- Verify each task has acceptance criteria.
- Flag any 'nice-to-have' additions to ZEUS.
