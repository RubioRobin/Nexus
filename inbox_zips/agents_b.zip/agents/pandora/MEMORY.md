# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- PRD history (versions)
- MVP definitions
- Acceptance_Criteria library
