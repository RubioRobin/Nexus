# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check assigned bugs.
- Attempt repro.
- Document findings.
