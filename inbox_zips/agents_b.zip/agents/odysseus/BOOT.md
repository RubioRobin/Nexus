# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Pull latest logs.
- Prepare minimal repro environment.
