# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm logging locations.
- Confirm how to capture Revit journal/logs.
