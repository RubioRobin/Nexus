# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Root_Cause_Report archive
- Known pitfalls list
