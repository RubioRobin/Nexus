# AGENTS
Role: Knowledge Base & Patterns

Standing operating rules:
- Maintain KB: patterns, fixes, reusable snippets.
- Index solutions and decisions.
Quality bar:
- Every entry has date + tags.
