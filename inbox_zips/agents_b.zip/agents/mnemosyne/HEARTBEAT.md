# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check new learnings to capture.
- Update index.
- Ensure no secrets in KB.
