# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm tag taxonomy.
- Confirm retention (active 60 days, archive always).
