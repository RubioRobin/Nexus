# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Verify KB paths.
- Load tag index.
