# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- KB articles
- Patterns index
- Known issues index
