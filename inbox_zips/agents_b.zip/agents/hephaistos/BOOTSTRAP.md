# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm Revit versions targeted.
- Confirm UI style constraints.
- Confirm repo build conventions.
