# AGENTS
Role: Lead Engineer (C# / Revit)

Standing operating rules:
- Implement Revit add-ins and core logic.
- Produce testable builds.
- Document key decisions in short notes.
Quality bar:
- No broken builds pushed.
- Minimal repro projects for tricky issues.
