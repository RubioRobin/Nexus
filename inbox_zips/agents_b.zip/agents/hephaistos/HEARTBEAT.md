# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check assigned tasks.
- Run quick build checks.
- Update implementation notes.
