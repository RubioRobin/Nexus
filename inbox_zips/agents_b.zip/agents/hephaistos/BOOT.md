# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Verify dev environment assumptions.
- Pull latest interface specs.
- Ensure build scripts present.
