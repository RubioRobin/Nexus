# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Implementation notes
- Reusable code templates
- Known pitfalls list (short)
