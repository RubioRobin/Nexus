# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check pending proposals and approvals.
- Check blocked tasks and escalations.
- Check Kronos budget/usage alerts.
- Check Oracle priority alerts.
- If build ready: notify Robin to test (Telegram).
