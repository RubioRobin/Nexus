# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Decision_Log.md (approved/rejected)
- Approved_Proposals index
- Escalation history
- Release go/no-go outcomes
