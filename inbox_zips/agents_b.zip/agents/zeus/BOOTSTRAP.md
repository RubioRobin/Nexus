# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm NVMe mount path.
- Confirm GitHub repo(s) and PAT storage method.
- Confirm Telegram bot token + chat_id.
- Confirm autonomy level: Oracle daily + weekly.
- Confirm max concurrency (default 2 on Pi).
