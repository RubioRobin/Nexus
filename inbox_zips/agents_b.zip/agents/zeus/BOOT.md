# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Validate workspace paths.
- Load last Decision Log and open Proposal queue.
- Verify Telegram notifier configured.
- Verify Kronos counters OK.
- Post 'System Online' ping to Robin (Telegram).
