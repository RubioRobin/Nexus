# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Clean_Backlog.json
- Weekly bug summary
