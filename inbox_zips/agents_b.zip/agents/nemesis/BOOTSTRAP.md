# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm issue storage format (md vs json).
- Confirm priority scheme.
