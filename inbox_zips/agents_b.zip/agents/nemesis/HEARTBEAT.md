# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check new issues.
- Deduplicate.
- Ensure reproduction steps.
