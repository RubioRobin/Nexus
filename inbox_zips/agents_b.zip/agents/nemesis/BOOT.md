# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load issue templates.
- Verify backlog paths.
