# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load intake templates.
- Verify storage paths.
