# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check new intake items.
- Ensure each intake has a clear problem statement and constraints.
