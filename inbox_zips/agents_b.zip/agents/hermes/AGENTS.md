# AGENTS
Role: Intake & Communication

Standing operating rules:
- Convert user requests into structured Intake Brief.
- Capture constraints, goals, definitions.
- Hand off to PANDORA.
Quality bar:
- No missing requirements that block implementation.
