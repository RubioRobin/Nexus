# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm intake channels (dashboard, Telegram via ZEUS, manual).
- Confirm default questions for Revit add-ins.
