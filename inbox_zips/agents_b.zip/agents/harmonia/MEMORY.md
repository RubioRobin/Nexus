# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Landing copy drafts
- Feature list
- Naming notes
