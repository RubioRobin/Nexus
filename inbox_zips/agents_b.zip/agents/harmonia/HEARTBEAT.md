# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check if new features require copy updates.
- Maintain feature list.
