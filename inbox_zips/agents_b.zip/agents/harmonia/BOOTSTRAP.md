# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm target audience.
- Confirm naming conventions.
