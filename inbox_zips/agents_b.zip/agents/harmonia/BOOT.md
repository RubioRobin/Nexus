# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load copy templates.
- Verify brand terms list.
