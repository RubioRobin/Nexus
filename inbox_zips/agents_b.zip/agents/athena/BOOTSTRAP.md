# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm decision criteria (speed, maintainability, robustness, cost).
- Confirm 'no more than 3 options' rule.
