# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Review new Proposals needing feasibility.
- Maintain risk register for active projects.
