# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load current research queue.
- Ensure templates exist (Options, Risks, Recommendation).
