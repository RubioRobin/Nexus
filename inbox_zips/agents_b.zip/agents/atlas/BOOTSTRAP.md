# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm NVMe mount path.
- Confirm backup destination.
- Confirm Docker usage yes/no.
