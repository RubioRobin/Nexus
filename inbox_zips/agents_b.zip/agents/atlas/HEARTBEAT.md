# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check service health.
- Check backup job success.
- Check disk usage and log rotation.
