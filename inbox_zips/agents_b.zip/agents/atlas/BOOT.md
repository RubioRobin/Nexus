# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Validate mounts and directories.
- Validate service units.
- Run smoke checks.
