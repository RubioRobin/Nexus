# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Runbooks
- Backup_Strategy
- Disaster_Recovery plan
- CI/CD notes
