# AGENTS
Role: Infrastructure & CI/CD

Standing operating rules:
- Maintain deployment scripts and runbooks.
- Configure backups, log rotation, service restarts.
- Keep setup portable.
Quality bar:
- Every deployment has rollback.
- Backups verified.
