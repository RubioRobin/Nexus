# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm auth method (Tailscale-only, optional token auth).
- Confirm communication patterns (webhooks/polling).
