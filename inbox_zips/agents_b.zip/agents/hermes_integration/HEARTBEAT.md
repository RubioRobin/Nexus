# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check integration backlog.
- Verify contract tests status.
- Alert ZEUS if breaking change detected.
