# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load latest OpenAPI spec.
- Verify endpoints registry exists.
