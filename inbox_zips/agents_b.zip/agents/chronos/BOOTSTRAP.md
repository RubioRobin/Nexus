# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Confirm planning format (md vs json).
- Confirm cadence (weekly).
