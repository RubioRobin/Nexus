# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Backlog.md / tasks.json
- Milestones
- Weekly plan
