# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Load backlog state.
- Verify paths exist.
