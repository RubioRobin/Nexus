# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check overdue tasks.
- Update timeline.
- Flag blockers to ZEUS.
