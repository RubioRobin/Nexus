# MEMORY
Curated long-term memory (agent-maintained). Only load when needed.

- Model_Usage_Log.json
- Monthly_Cost_Report.md
- Alert history (what/when/why)
