# HEARTBEAT
Tiny recurring checklist (every ~30 min). Keep short.

- Check concurrency (target <= 2).
- Check disk usage for logs/reports.
- Check any non-local model usage events.
- If thresholds exceeded: alert ZEUS.
