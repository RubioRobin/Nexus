# BOOTSTRAP
One-time onboarding interview. Delete after setup.

- Set monthly caps (CPU/time budget) and log retention days.
- Confirm what counts as 'escalation' event.
