# BOOT
Startup ritual on gateway restart (requires hooks enabled).

- Rotate logs (if enabled).
- Reset daily counters.
- Verify report directories exist.
