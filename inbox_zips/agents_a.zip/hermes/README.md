# Hermes
This is the hermes agent's workspace. It will run on ChatGPT.