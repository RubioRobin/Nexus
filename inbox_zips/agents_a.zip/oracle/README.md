# Oracle
This is the oracle agent's workspace. It will run on ChatGPT.