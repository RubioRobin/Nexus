# Mnemosyne
This is the mnemosyne agent's workspace. It will run on ChatGPT.