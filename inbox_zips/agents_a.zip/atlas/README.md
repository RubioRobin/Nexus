# Atlas
This is the atlas agent's workspace. It will run on ChatGPT.