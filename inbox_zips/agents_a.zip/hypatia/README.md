# Hypatia
This is the hypatia agent's workspace. It will run on ChatGPT.