# Kronos
This is the kronos agent's workspace. It will run on ChatGPT.