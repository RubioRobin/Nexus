# Nemesis
This is the nemesis agent's workspace. It will run on ChatGPT.