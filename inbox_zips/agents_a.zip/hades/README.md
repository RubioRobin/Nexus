# Hades
This is the hades agent's workspace. It will run on ChatGPT.