# USER
Preferred name: Robin
Timezone: Europe/Amsterdam
Primary focus: Task execution and coordination.
