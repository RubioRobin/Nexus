# BOOT
Initialization routine for ChatGPT-based agent.