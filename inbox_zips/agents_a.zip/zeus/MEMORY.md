# MEMORY
This agent uses long-term memory for task tracking and context management.