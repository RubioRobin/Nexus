# Odysseus
This is the odysseus agent's workspace. It will run on ChatGPT.